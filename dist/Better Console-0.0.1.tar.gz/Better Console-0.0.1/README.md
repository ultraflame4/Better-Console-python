# Better Console
Provides a better console for python programs to use

## Features:
Filters for Debug, Info, Warning, Critical , Error and Normal messages
Text input bar to execute commands
